package org.tutorial;

import java.sql.SQLException;
import java.util.List;

public interface ServeurDAO {
	public List<Serveur> findByAll() throws SQLException;

}
