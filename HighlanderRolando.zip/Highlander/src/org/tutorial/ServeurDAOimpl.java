package org.tutorial;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ServeurDAOimpl implements ServeurDAO {

	@Override
	public List<Serveur> findByAll() throws SQLException {
		List<Serveur> Liste = new ArrayList<Serveur>();
		Connection connec = DBManager.getInstance().getConnection();
		Statement statement = connec.createStatement();
		ResultSet rs = statement.executeQuery("SELECT * from Serveurs");
		while (rs.next()) {
			String nom = rs.getString("nom");
			String type = rs.getString("type");
			Serveur p = new Serveur(nom, type);
			Liste.add(p);
		}
		return Liste;
	}
}
