package org.tutorial;

import java.sql.SQLException;
import java.util.List;

public interface PanneService {
	public List<Panne> getAllPanne() throws SQLException;

	public List<Panne> getPanneByDateDiff(int minuteDiff) throws SQLException;
}
