package org.tutorial;

import java.sql.SQLException;
import java.util.List;

public interface PanneDAO {
	public List<Panne> findByAll() throws SQLException;

	List<Panne> findByDateDiff(int minuteDiff) throws SQLException;
}
