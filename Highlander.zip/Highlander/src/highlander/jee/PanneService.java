package highlander.jee;

import java.sql.SQLException;
import java.util.List;

public interface PanneService {
	public List<Panne> getAllPanne() throws SQLException;

	public List<Panne> getPanneByDateDiff(int minuteDiff) throws SQLException;

	public void addPanne(String nom, String type) throws SQLException;

	public void addRandomPanne(int nb) throws SQLException;
}
