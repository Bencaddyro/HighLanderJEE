package highlander.jee;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class TimerPannes extends TimerTask {
	private Timer timer;
	private int nb_pannes;
	private static PanneService gestionnaire = new PanneServiceImpl();
	private static List<TimerTask> listTimer = new ArrayList<TimerTask>();

	public TimerPannes(int nb) {
		this.nb_pannes = nb;
		timer = new Timer(true);
	}

	public static void lancer(int _duree, int _nb_pannes) throws SQLException {
		double periode = (double) (_duree) / Math.abs(_nb_pannes);
		TimerTask timerPannes = new TimerPannes(_nb_pannes);
		((TimerPannes) timerPannes).timer.scheduleAtFixedRate(timerPannes, 0, (long) (periode * 1000));
		listTimer.add(timerPannes);
	}

	public PanneService getGestionnaire() {
		return this.gestionnaire;
	}

	public void stop() {
		timer.cancel();
		timer.purge();
		listTimer.remove(this);
	}

	public static void stopTout() {
		while (!listTimer.isEmpty()) {
			((TimerPannes) listTimer.get(0)).stop();
		}
	}

	public static Boolean getTask() {
		return listTimer.isEmpty();
	}

	@Override
	public void run() {
		try {
			gestionnaire.addRandomPanne(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.nb_pannes--;
		if (this.nb_pannes == 0) {
			this.stop();
		}
	}
}
