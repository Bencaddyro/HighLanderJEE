package highlander.jee;

import java.sql.SQLException;
import java.util.Timer;
import java.util.TimerTask;

public class TimerPannes extends TimerTask {
	private static TimerPannes instance = new TimerPannes();
	private int nb_secondes;
	private PanneDAOImpl gestionnaire = new PanneDAOImpl();

	public static TimerPannes getInstance() {
		return instance;
	}

	public void lancer(int _nb_secondes) {
		Timer timer = new Timer(true);
		this.nb_secondes = _nb_secondes;
		try {
			gestionnaire.addRandomPanne(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		timer.scheduleAtFixedRate(instance, 0, nb_secondes * 1000);
	}

	@Override
	public void run() {
		try {
			gestionnaire.addRandomPanne(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
