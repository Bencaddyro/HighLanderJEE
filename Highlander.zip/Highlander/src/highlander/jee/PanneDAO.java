package highlander.jee;

import java.sql.SQLException;
import java.util.List;

public interface PanneDAO {
	public List<Panne> findByAll() throws SQLException;

	public List<Panne> findByDateDiff(int minuteDiff) throws SQLException;

	public List<Panne> findByDateDiff(int minuteDiff, String type_machine) throws SQLException;

	public void addPanne(String nom, String type) throws SQLException;

	public void addRandomPanne(int nb) throws SQLException;

	public void solvePanne(String nameServeur) throws SQLException;

	public int countByDateDiff(int date_sup, int date_inf) throws SQLException;

	public int countMachineByDateDiff(int date_sup, int date_inf, String type_machine) throws SQLException;

	public int countPanneByDateDiff(int date_sup, int date_inf, String type_panne) throws SQLException;

}
