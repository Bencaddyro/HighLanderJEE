package highlander.jee;

public class PareFeux extends Machine {

	public PareFeux(String _nom) {
		super(_nom);
	}

	public String toString() {
		return this.getNom() + "/Pare-Feux";
	}
}
