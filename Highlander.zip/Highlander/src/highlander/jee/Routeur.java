package highlander.jee;

public class Routeur extends Machine {

	public Routeur(String _nom) {
		super(_nom);
	}

	public String toString() {
		return this.getNom() + "/Routeur";
	}
}
