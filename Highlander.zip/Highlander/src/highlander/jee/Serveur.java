package highlander.jee;

public class Serveur extends Machine {

	public Serveur(String _nom) {
		super(_nom);
	}

	public String genPanne() {
		int a = (int) (Math.random() * 3);
		switch (a) {
		case 0:
			return ("Disque");
		case 1:
			return ("Memoire");
		default:
			return ("Reseau");
		}
	}

	public String toString() {
		return this.getNom() + "/Serveur";
	}
}
