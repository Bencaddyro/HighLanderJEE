package highlander.jee;

public abstract class Machine {
	private String nom;

	public Machine(String _nom) {
		this.nom = _nom;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String genPanne() {
		return ("Reseau");
	}

	public String toString() {
		return this.getNom();
	}
}
