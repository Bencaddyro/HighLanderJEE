package highlander.jee;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class VuesPannes
 */
// @WebServlet("/MainServlet2")
public class VuesPannes extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VuesPannes() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			doProcess(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			doProcess(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void doProcess(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		String pageName = "/VuePannes.jsp";

		PanneService panneService = new PanneServiceImpl();

		List<Panne> listPanne = new ArrayList<Panne>();
		listPanne = panneService.getPanneByDateDiff(1);

		request.setAttribute("listPanne", listPanne);

		PanneService panneService2 = new PanneServiceImpl();

		List<Panne> listPanne2 = new ArrayList<Panne>();
		listPanne2 = panneService2.getPanneByDateDiff(60);

		request.setAttribute("listPanne2", listPanne2);

		PanneService panneService3 = new PanneServiceImpl();

		List<Panne> listPanne3 = new ArrayList<Panne>();
		listPanne3 = panneService3.getPanneByDateDiff(60 * 24);

		request.setAttribute("listPanne3", listPanne3);

		PanneService panneService4 = new PanneServiceImpl();

		List<Panne> listPanne4 = new ArrayList<Panne>();
		listPanne4 = panneService4.getPanneByDateDiff(60 * 24 * 30);

		request.setAttribute("listPanne4", listPanne4);

		PanneService panneService5 = new PanneServiceImpl();

		List<Panne> listPanne5 = new ArrayList<Panne>();
		listPanne5 = panneService5.getPanneByDateDiff(60 * 24 * 30, "Serveur");

		request.setAttribute("listPanne5", listPanne5);

		PanneService panneService6 = new PanneServiceImpl();

		List<Panne> listPanne6 = new ArrayList<Panne>();
		listPanne6 = panneService6.getPanneByDateDiff(60 * 24 * 30, "Routeur");

		request.setAttribute("listPanne6", listPanne6);

		RequestDispatcher rd = getServletContext().getRequestDispatcher(pageName);
		try {
			rd.forward(request, response);
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
