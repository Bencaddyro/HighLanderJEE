package highlander.jee;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class MachineDAOimpl implements MachineDAO {

	@Override
	public List<Machine> findByAll() throws SQLException {
		List<Machine> Liste = new ArrayList<Machine>();
		Connection connec = DBManager.getInstance().getConnection();
		Statement statement = connec.createStatement();
		ResultSet rs = statement.executeQuery("SELECT * from Machines");
		while (rs.next()) {
			Machine p = null;
			String nom = rs.getString("Nom");
			String type = rs.getString("Type");

			if (type.equals("Serveur")) {
				p = new Serveur(nom);
			}
			if (type.equals("Pare-Feux")) {
				p = new PareFeux(nom);
			}
			if (type.equals("Routeur")) {
				p = new Routeur(nom);
			}

			if (p != null) {
				Liste.add(p);
			}
		}
		return Liste;
	}
}
