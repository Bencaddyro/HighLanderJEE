package highlander.jee;

import java.sql.SQLException;
import java.util.List;

public interface MachineDAO {
	public List<Machine> findByAll() throws SQLException;

}
