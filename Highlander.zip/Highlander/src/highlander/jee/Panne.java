package highlander.jee;

import java.sql.Timestamp;

public class Panne {
	private String serveur_nom;
	private Timestamp date;
	private String type;
	private int status;

	public Panne(String serveur_nom, Timestamp date, String type, int status) {
		this.serveur_nom = serveur_nom;
		this.date = date;
		this.type = type;
		this.status = status;
	}

	public Timestamp getDate() {
		return date;
	}

	public String getServeur_nom() {
		return serveur_nom;
	}

	public int getStatus() {
		return status;
	}

	public String getType() {
		return type;
	}
}
