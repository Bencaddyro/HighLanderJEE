package org.tutorial;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class PanneDAOImpl implements PanneDAO {

	@Override
	public List<Panne> findByAll() throws SQLException {
		List<Panne> Liste = new ArrayList<Panne>();
		Connection connec = DBManager.getInstance().getConnection();
		Statement statement = connec.createStatement();
		ResultSet rs = statement.executeQuery("SELECT * from Pannes");
		while (rs.next()) {
			String serveur_nom = rs.getString("Serveurs_nom");
			String type_machine = rs.getString("type_machine");
			Timestamp date = rs.getTimestamp("Date");
			String type = rs.getString("type");
			int status = rs.getInt("Status");
			Panne p = new Panne(serveur_nom, type_machine, date, type, status);
			Liste.add(p);
		}
		return Liste;
	}

	@Override
	public List<Panne> findByDateDiff(int minuteDiff) throws SQLException {
		List<Panne> Liste = new ArrayList<Panne>();
		Connection connec = DBManager.getInstance().getConnection();
		Statement statement = connec.createStatement();
		ResultSet rs = statement.executeQuery(
				"SELECT Serveurs_nom,type_machine,Date,type,Status from Pannes JOIN Serveurs ON Pannes.Serveurs_nom=Serveurs.nom where TIMESTAMPDIFF(MINUTE,Date,NOW())<"
						+ minuteDiff);
		while (rs.next()) {
			String serveur_nom = rs.getString("Serveurs_nom");
			String type_machine = rs.getString("type_machine");
			Timestamp date = rs.getTimestamp("Date");
			String type = rs.getString("type");
			int status = rs.getInt("Status");
			Panne p = new Panne(serveur_nom, type_machine, date, type, status);
			Liste.add(p);
		}
		return Liste;
	}

	public List<Panne> findByDateDiff(int minuteDiff, String type_machine) throws SQLException {
		List<Panne> Liste = new ArrayList<Panne>();
		Connection connec = DBManager.getInstance().getConnection();
		Statement statement = connec.createStatement();
		ResultSet rs = statement.executeQuery(
				"SELECT Serveurs_nom,type_machine,Date,type,Status from Pannes JOIN Serveurs ON Pannes.Serveurs_nom=Serveurs.nom where type_machine='"
						+ type_machine + "' AND TIMESTAMPDIFF(MINUTE,Date,NOW())<" + minuteDiff);
		while (rs.next()) {
			String serveur_nom = rs.getString("Serveurs_nom");
			String type__machine = rs.getString("type_machine");
			Timestamp date = rs.getTimestamp("Date");
			String type = rs.getString("type");
			int status = rs.getInt("Status");
			Panne p = new Panne(serveur_nom, type__machine, date, type, status);
			Liste.add(p);
		}
		return Liste;
	}
}
