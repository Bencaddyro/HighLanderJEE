package org.tutorial;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class PanneDAOImpl implements PanneDAO {

	@Override
	public List<Panne> findByAll() throws SQLException {
		List<Panne> Liste = new ArrayList<Panne>();
		Connection connec = DBManager.getInstance().getConnection();
		Statement statement = connec.createStatement();
		ResultSet rs = statement.executeQuery("SELECT * from Pannes");
		while (rs.next()) {
			String serveur_nom = rs.getString("Serveurs_nom");
			Timestamp date = rs.getTimestamp("Date");
			String type = rs.getString("type");
			int status = rs.getInt("Status");
			Panne p = new Panne(serveur_nom, date, type, status);
			Liste.add(p);
		}
		return Liste;
	}

	@Override
	public List<Panne> findByDateDiff(int minuteDiff) throws SQLException {
		List<Panne> Liste = new ArrayList<Panne>();
		Connection connec = DBManager.getInstance().getConnection();
		Statement statement = connec.createStatement();
		ResultSet rs = statement
				.executeQuery("SELECT * from Pannes where TIMESTAMPDIFF(MINUTE,NOW(),Date)<" + minuteDiff);
		while (rs.next()) {
			String serveur_nom = rs.getString("Serveurs_nom");
			Timestamp date = rs.getTimestamp("Date");
			String type = rs.getString("type");
			int status = rs.getInt("Status");
			Panne p = new Panne(serveur_nom, date, type, status);
			Liste.add(p);
		}
		return Liste;
	}

}
