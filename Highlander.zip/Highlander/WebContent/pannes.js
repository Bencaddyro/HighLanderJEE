function actualisationFunction(mydiv) {
	division = mydiv;
	division.innerHTML = "Panne résolue";
	division.style.backgroundColor = "#4CAF50";
}

