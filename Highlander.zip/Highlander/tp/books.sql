create database enssat_tp;
use enssat_tp;



SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


-- --------------------------------------------------------

--
-- Structure de la table 'books'
--

CREATE TABLE IF NOT EXISTS books (
  id int(11) NOT NULL,
  title varchar(255) NOT NULL,
  author varchar(255) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table 'books'
--

INSERT INTO books (id, title, author) VALUES
(1, 'Thinking in Java', 'Bruce Eckel'),
(2, 'Le Seigneur des Anneaux', 'Tolkien'),
(3, 'Da Vinci Code', 'Dan Brown'),
(4, 'Internet pour les nuls', 'John Levine'),
(5, '99F', 'Frédéric Beigbeder'),
(6, 'Le bourgeois Gentilhomme', 'Molière'),
(7, 'Guerre et Paix', 'Tolstoï');

