package highlander.jee;

import java.sql.SQLException;
import java.util.List;

public class PanneServiceImpl implements PanneService {
	private PanneDAO panneDao = new PanneDAOImpl();

	public List<Panne> getAllPanne() throws SQLException {
		return this.panneDao.findByAll();
	}

	@Override
	public List<Panne> getPanneByDateDiff(int minuteDiff) throws SQLException {
		return panneDao.findByDateDiff(minuteDiff);
	}

	@Override
	public List<Panne> getPanneByDateDiff(int minuteDiff, String type_machine) throws SQLException {
		return panneDao.findByDateDiff(minuteDiff, type_machine);
	}

	public void addPanne(String nom, String type) throws SQLException {
		this.panneDao.addPanne(nom, type);
	}

	public void addRandomPanne(int nb) throws SQLException {
		this.panneDao.addRandomPanne(nb);
	}

	public int countByDateDiff(int date_sup, int date_inf) throws SQLException {
		return panneDao.countByDateDiff(date_sup, date_inf);
	}

	public int countMachineByDateDiff(int date_sup, int date_inf, String type_machine) throws SQLException {
		return panneDao.countMachineByDateDiff(date_sup, date_inf, type_machine);
	}

	public int countPanneByDateDiff(int date_sup, int date_inf, String type_panne) throws SQLException {
		return panneDao.countPanneByDateDiff(date_sup, date_inf, type_panne);
	}

}
