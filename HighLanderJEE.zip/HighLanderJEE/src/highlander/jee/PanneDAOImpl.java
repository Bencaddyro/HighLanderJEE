package highlander.jee;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class PanneDAOImpl implements PanneDAO {

	@Override
	public List<Panne> findByAll() throws SQLException {
		List<Panne> Liste = new ArrayList<Panne>();
		Connection connec = DBManager.getInstance().getConnection();
		Statement statement = connec.createStatement();
		ResultSet rs = statement.executeQuery(
				"SELECT Machines_Nom,Type_Machine,Date,Type,Status from Pannes JOIN Machines ON Pannes.Machines_Nom=Machines.Nom ");
		while (rs.next()) {
			String serveur_nom = rs.getString("Machines_Nom");
			String type__machine = rs.getString("Type_Machine");
			Timestamp date = rs.getTimestamp("Date");
			String type = rs.getString("Type");
			int status = rs.getInt("Status");
			Panne p = new Panne(serveur_nom, type__machine, date, type, status);
			Liste.add(p);
		}
		return Liste;
	}

	@Override
	public List<Panne> findByDateDiff(int minuteDiff) throws SQLException {
		List<Panne> Liste = new ArrayList<Panne>();
		Connection connec = DBManager.getInstance().getConnection();
		Statement statement = connec.createStatement();
		ResultSet rs = statement.executeQuery(
				"SELECT Machines_Nom,Type_Machine,Date,Type,Status from Pannes JOIN Machines ON Pannes.Machines_Nom=Machines.Nom "
						+ "where TIMESTAMPDIFF(MINUTE,Date,NOW())<" + minuteDiff);
		while (rs.next()) {
			String serveur_nom = rs.getString("Machines_Nom");
			String type__machine = rs.getString("Type_Machine");
			Timestamp date = rs.getTimestamp("Date");
			String type = rs.getString("Type");
			int status = rs.getInt("Status");
			Panne p = new Panne(serveur_nom, type__machine, date, type, status);
			Liste.add(p);
		}
		return Liste;
	}

	@Override
	public List<Panne> findByDateDiff(int minuteDiff, String type_machine) throws SQLException {
		List<Panne> Liste = new ArrayList<Panne>();
		Connection connec = DBManager.getInstance().getConnection();
		Statement statement = connec.createStatement();
		ResultSet rs = statement.executeQuery(
				"SELECT Machines_Nom,Type_Machine,Date,Type,Status from Pannes JOIN Machines ON Pannes.Machines_Nom=Machines.Nom where Type_Machine='"
						+ type_machine + "' AND TIMESTAMPDIFF(MINUTE,Date,NOW())<" + minuteDiff);
		while (rs.next()) {
			String serveur_nom = rs.getString("Machines_Nom");
			String type__machine = rs.getString("Type_Machine");
			Timestamp date = rs.getTimestamp("Date");
			String type = rs.getString("Type");
			int status = rs.getInt("Status");
			Panne p = new Panne(serveur_nom, type__machine, date, type, status);
			Liste.add(p);
		}
		return Liste;
	}

	@Override
	public void addPanne(String nom, String type) throws SQLException {
		Connection connec = DBManager.getInstance().getConnection();
		Statement statement = connec.createStatement();
		statement.executeUpdate(
				"insert into Pannes VALUES ( '" + nom.toString() + "',NOW(), '" + type.toString() + "',0);");

	}

	@Override
	public void addRandomPanne(int nb) throws SQLException {
		List<Machine> listMachine = (new MachineDAOimpl().findByAll());
		int i;
		String nom;
		Machine cible;
		String type;
		for (i = 0; i < nb; i++) {
			cible = listMachine.get((int) (Math.random() * listMachine.size()));
			nom = cible.getNom();
			type = cible.genPanne();
			this.addPanne(nom, type);
			listMachine.remove(cible);
		}
	}

	@Override
	public int countByDateDiff(int date_sup, int date_inf) throws SQLException {
		int compteur = 0;
		Connection connec = DBManager.getInstance().getConnection();
		Statement statement = connec.createStatement();
		ResultSet rs = statement
				.executeQuery("SELECT Count(*) from Pannes JOIN Machines ON Pannes.Machines_Nom=Machines.Nom "
						+ "where TIMESTAMPDIFF(MINUTE,Date,NOW())<=" + date_sup
						+ "AND TIMESTAMPDIFF(MINUTE,Date,NOW())>" + date_inf);
		while (rs.next()) {
			compteur = rs.getInt("Count(*)");
		}
		return compteur;

	}

	@Override
	public int countMachineByDateDiff(int date_sup, int date_inf, String type_machine) throws SQLException {
		int compteur = 1;
		Connection connec = DBManager.getInstance().getConnection();
		Statement statement = connec.createStatement();
		ResultSet rs = statement.executeQuery(
				"SELECT Count(*) from Pannes JOIN Machines ON Pannes.Machines_Nom=Machines.Nom where Type_Machine='"
						+ type_machine + "AND TIMESTAMPDIFF(MINUTE,Date,NOW())<=" + date_sup
						+ "AND TIMESTAMPDIFF(MINUTE,Date,NOW())>" + date_inf);
		while (rs.next()) {
			compteur = rs.getInt("Count(*)");
		}
		return compteur;
	}

	@Override
	public int countPanneByDateDiff(int date_sup, int date_inf, String type_panne) throws SQLException {

		int compteur = 1;
		Connection connec = DBManager.getInstance().getConnection();
		Statement statement = connec.createStatement();
		ResultSet rs = statement.executeQuery(
				"SELECT Count(*) from Pannes JOIN Machines ON Pannes.Machines_Nom=Machines.Nom where Type='"
						+ type_panne + "TIMESTAMPDIFF(MINUTE,Date,NOW())<=" + date_sup
						+ "AND TIMESTAMPDIFF(MINUTE,Date,NOW())>" + date_inf);
		while (rs.next()) {
			compteur = rs.getInt("Count(*)");
		}
		return compteur;
	}

}
