package org.tutorial;

import java.sql.SQLException;
import java.util.List;

public class PanneServiceImpl implements PanneService {
	private PanneDAO panneDao = new PanneDAOImpl();

	public List<Panne> getAllPanne() throws SQLException {
		return this.panneDao.findByAll();
	}

	@Override
	public List<Panne> getPanneByDateDiff(int minuteDiff) throws SQLException {
		return panneDao.findByDateDiff(minuteDiff);
	}
}
